#!/usr/bin/env bash
pkill -f "/home/ec2-user/app/app.jar" || true